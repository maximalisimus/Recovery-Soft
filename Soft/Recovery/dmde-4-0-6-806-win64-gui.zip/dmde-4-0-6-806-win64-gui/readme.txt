
  DMDE (Disk Editor and Data Recovery Software)
  The software is to search, edit, and recover data on disks

  Copyright (c) 2005-2020 Dmitry Sidorov

  WWW:    http://dmde.com/
          http://softdm.com/

  The software may be used under the terms of the license 
  agreements in the file "eula.txt"

  Be sure to know system requirements before use (read the manual)
