Handy Recovery� is an easy-to-use data recovery software designed to restore files accidentally deleted from hard disks and floppy drives. The program can recover files damaged by virus attacks, power failures and software faults or files from deleted and formatted partitions. If some program does not use Recycle Bin when deleting files, Handy Recovery can restore such files. It can also recover files moved to Recycle Bin after it has been emptied.
With Handy Recovery you can browse the content of your disk like you do it in Windows Explorer. The only difference is that you see deleted files and folders along with the regular ones. The program can search for files by name or mask and show the probability of successful recovery for each file. Recovered files can be saved to any disks accessible on your system. You can also restore the full branch of folders tree containing selected files and folders. Along with the main file data, the program can recover alternate data streams which are used on NTFS file system to store additional information about files. Handy Recovery works under Win 95/98/Me/NT/2000/XP/2003 operating systems. The program supports all Windows file systems for hard and floppy drives including FAT12/16/32, NTFS/NTFS 5 and image recovery from CompactFlash, SmartMedia, MultiMedia and Secure Digital cards. It can recover compressed and encrypted files on NTFS drives.
What's new in version 4.0

- Files deleted from Recycle Bin are gathered in a special folder;
- Preview window to show the content of deleted files;
- HFS/HFS+ file systems support;
- Optimized extended analysis takes less time.



1. Copy Patch-file in the install directory of the Program
2. Apply Patch
