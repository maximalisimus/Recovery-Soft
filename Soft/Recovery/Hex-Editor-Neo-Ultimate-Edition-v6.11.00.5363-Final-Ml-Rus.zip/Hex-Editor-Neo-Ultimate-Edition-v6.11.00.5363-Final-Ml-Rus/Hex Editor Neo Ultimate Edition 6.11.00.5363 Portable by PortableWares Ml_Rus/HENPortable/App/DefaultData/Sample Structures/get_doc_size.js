// Copyright (c) 2015 by HHD Software Ltd.
// This file is part of the HHD Software Hex Editor
// For usage and distribution policies, consult the license distributed with a product installation program

// Get the current document size
function GetDocumentSize()
{
    return document.FileSize;
}
