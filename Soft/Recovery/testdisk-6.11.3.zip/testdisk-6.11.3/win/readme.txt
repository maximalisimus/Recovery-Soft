The Windows version of TestDisk & PhotoRec should work under
- Windows NT 4
- Windows 2000
- Windows XP
- Windows 2003
- Windows Vista

If you are using an older version of Windows, run the DOS version of TestDisk.
You can download it from http://www.cgsecurity.org/wiki/TestDisk_Download

TestDisk doesn't need to be installed, you only need to
- extract the directory "win" and its subdirectory "win\c"
- run testdisk_win.exe or photorec_win.exe

TestDisk & PhotoRec documentation can be found online:
- http://www.cgsecurity.org/wiki/TestDisk
- http://www.cgsecurity.org/wiki/PhotoRec
Documentation can be downloaded from
- http://www.cgsecurity.org/wiki/TestDisk_Download
